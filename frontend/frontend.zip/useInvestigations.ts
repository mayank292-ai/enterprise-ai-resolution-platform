import { useEffect, useRef } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  approveCapabilityGap,
  createInvestigation,
  getInvestigation,
  listInvestigations,
  resumeInvestigation,
  runInvestigation,
} from "../api/investigations";
import type { Investigation, InvestigationRequest } from "../types/investigation";

export const investigationKeys = {
  all: ["investigations"] as const,
  list: () => [...investigationKeys.all, "list"] as const,
  detail: (id: string) => [...investigationKeys.all, "detail", id] as const,
};

const ACTIVE_STATUSES = new Set(["created", "planning", "investigating", "verifying"]);

export function useInvestigationsList() {
  return useQuery({
    queryKey: investigationKeys.list(),
    queryFn: listInvestigations,
    refetchInterval: (query) => {
      const data = query.state.data;
      const hasActive = data?.some((inv) => ACTIVE_STATUSES.has(inv.status));
      return hasActive ? 4000 : false;
    },
  });
}

export function useCreateInvestigation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (request: InvestigationRequest) => createInvestigation(request),
    onSuccess: (investigation) => {
      queryClient.setQueryData(investigationKeys.detail(investigation.investigation_id), investigation);
      queryClient.invalidateQueries({ queryKey: investigationKeys.list() });
    },
  });
}

/**
 * Drives a single investigation from its current backend status through
 * to a terminal state. The backend requires an explicit POST /run to
 * advance each supervisor step (it is not a passive background job), so
 * this hook polls GET for display state and, while the investigation is
 * in an active status, calls /run on an interval to keep it moving.
 * It freezes on `awaiting_capability_approval`, `completed`, and `failed`.
 */
export function useInvestigationSession(investigationId: string | undefined) {
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: investigationKeys.detail(investigationId ?? ""),
    queryFn: () => getInvestigation(investigationId as string),
    enabled: Boolean(investigationId),
    refetchInterval: (q) => {
      const status = q.state.data?.status;
      if (!status) return 2000;
      if (ACTIVE_STATUSES.has(status)) return 1800;
      if (status === "awaiting_capability_approval") return 5000;
      return false;
    },
  });

  const runStep = useMutation({
    mutationFn: () => runInvestigation(investigationId as string),
    onSuccess: (investigation) => {
      queryClient.setQueryData(investigationKeys.detail(investigation.investigation_id), investigation);
    },
  });

  const approve = useMutation({
    mutationFn: () => approveCapabilityGap(investigationId as string),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: investigationKeys.detail(investigationId as string) });
    },
  });

  const resume = useMutation({
    mutationFn: () => resumeInvestigation(investigationId as string),
    onSuccess: (investigation) => {
      queryClient.setQueryData(investigationKeys.detail(investigation.investigation_id), investigation);
      queryClient.invalidateQueries({ queryKey: investigationKeys.list() });
    },
  });

  // Auto-drive: while the investigation is in an active status, call
  // /run on an interval so the supervisor keeps advancing without the
  // user manually clicking anything. Guarded against overlapping calls.
  const runningRef = useRef(false);
  useEffect(() => {
    const status = query.data?.status;
    if (!investigationId || !status || !ACTIVE_STATUSES.has(status)) {
      return;
    }

    let cancelled = false;

    const tick = () => {
      if (cancelled || runningRef.current) return;
      runningRef.current = true;
      runStep
        .mutateAsync()
        .catch(() => {
          /* surfaced via runStep.error in the UI */
        })
        .finally(() => {
          runningRef.current = false;
        });
    };

    const interval = setInterval(tick, 1800);
    tick();

    return () => {
      cancelled = true;
      clearInterval(interval);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [investigationId, query.data?.status]);

  return { query, runStep, approve, resume };
}

export function isActiveStatus(status: Investigation["status"]) {
  return ACTIVE_STATUSES.has(status);
}
