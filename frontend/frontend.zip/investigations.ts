import { apiClient } from "./client";
import { investigationSchema } from "./schemas";
import type { Investigation, InvestigationRequest, CapabilityGap } from "../types/investigation";

const BASE = "/api/v1/investigations";

function parse(data: unknown): Investigation {
  // Structural validation only — never throws away real backend fields.
  return investigationSchema.parse(data) as unknown as Investigation;
}

export async function createInvestigation(
  request: InvestigationRequest
): Promise<Investigation> {
  const response = await apiClient.post(BASE, request);
  return parse(response.data);
}

export async function listInvestigations(): Promise<Investigation[]> {
  const response = await apiClient.get(BASE);
  return (response.data as unknown[]).map(parse);
}

export async function getDemoInvestigation(): Promise<Investigation> {
  const response = await apiClient.get(`${BASE}/demo`);
  return parse(response.data);
}

export async function getInvestigation(investigationId: string): Promise<Investigation> {
  const response = await apiClient.get(`${BASE}/${investigationId}`);
  return parse(response.data);
}

export async function runInvestigation(investigationId: string): Promise<Investigation> {
  const response = await apiClient.post(`${BASE}/${investigationId}/run`);
  return parse(response.data);
}

export async function approveCapabilityGap(investigationId: string): Promise<CapabilityGap> {
  const response = await apiClient.post(`${BASE}/${investigationId}/capability-gap/approve`);
  return response.data as CapabilityGap;
}

export async function resumeInvestigation(investigationId: string): Promise<Investigation> {
  const response = await apiClient.post(`${BASE}/${investigationId}/resume`);
  return parse(response.data);
}
