import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Check, Loader2 } from "lucide-react";
import { OrbitMotif } from "@/components/ui/OrbitMotif";

const STEPS = [
  "Defining capability",
  "Applying workspace policy",
  "Registering specialist",
  "Capability ready",
];

interface ProvisioningSequenceProps {
  agentName: string;
  onComplete: () => void;
}

/**
 * Purely a local animation timeline (2.2-3.5s as specified). The real
 * capability-gap/approve call has already completed by the time this
 * mounts; onComplete triggers the real resume call.
 */
export function ProvisioningSequence({ agentName, onComplete }: ProvisioningSequenceProps) {
  const [stepIndex, setStepIndex] = useState(0);

  useEffect(() => {
    if (stepIndex >= STEPS.length) {
      const timeout = setTimeout(onComplete, 400);
      return () => clearTimeout(timeout);
    }
    const timeout = setTimeout(() => setStepIndex((i) => i + 1), 700);
    return () => clearTimeout(timeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stepIndex]);

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-midnight/85 backdrop-blur-md">
      <div className="flex flex-col items-center gap-6 text-center px-4">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
          className="text-electric"
        >
          <OrbitMotif size={64} progress={stepIndex / STEPS.length} active />
        </motion.div>
        <div>
          <h2 className="text-white text-lg font-semibold mb-1">Provisioning {agentName}</h2>
          <p className="text-slate-300 text-sm">Registering a governed specialist capability</p>
        </div>
        <ul className="space-y-2 text-left w-64">
          {STEPS.map((step, i) => (
            <li key={step} className="flex items-center gap-2.5 text-sm">
              <span className="flex items-center justify-center w-5 h-5 rounded-full shrink-0">
                <AnimatePresence mode="wait">
                  {i < stepIndex ? (
                    <motion.span
                      key="done"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="flex items-center justify-center w-5 h-5 rounded-full bg-verified text-white"
                    >
                      <Check className="w-3 h-3" />
                    </motion.span>
                  ) : i === stepIndex ? (
                    <Loader2 className="w-4 h-4 text-electric animate-spin" />
                  ) : (
                    <span className="w-1.5 h-1.5 rounded-full bg-white/20" />
                  )}
                </AnimatePresence>
              </span>
              <span className={i <= stepIndex ? "text-white" : "text-slate-300"}>{step}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
