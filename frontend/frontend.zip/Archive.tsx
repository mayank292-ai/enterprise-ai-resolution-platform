import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Clock3, FileText, Filter, Play, Search, ShieldCheck, Sparkles } from "lucide-react";
import { useInvestigationsList } from "@/hooks/useInvestigations";
import { Card } from "@/components/ui/Card";
import { Input, Select } from "@/components/ui/Field";
import { StatusBadge, Badge } from "@/components/ui/Badge";
import { LoadingState } from "@/components/ui/States";
import { formatCurrency, formatDuration, formatRelativeTime } from "@/lib/utils";
import type { InvestigationStatus } from "@/types/investigation";
import { historicalInvestigations } from "@/data/history";

export function Archive() {
  const navigate = useNavigate();
  const { data: investigations, isLoading } = useInvestigationsList();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<InvestigationStatus | "all">("all");

  const filtered = useMemo(() => {
    return (investigations ?? [])
      .filter((inv) => statusFilter === "all" || inv.status === statusFilter)
      .filter((inv) => inv.incident_title.toLowerCase().includes(search.toLowerCase()))
      .sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime());
  }, [investigations, statusFilter, search]);

  const curated = historicalInvestigations.filter((item) => item.title.toLowerCase().includes(search.toLowerCase()));
  if (isLoading) return <LoadingState label="Loading investigations" className="py-24" />;

  return (
    <div className="mx-auto max-w-7xl space-y-7 px-6 py-8 lg:px-8">
      <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
        <div><div className="mb-2 flex items-center gap-2 text-2xs font-semibold uppercase tracking-[.18em] text-enterprise"><Sparkles className="h-3.5 w-3.5" /> Investigation intelligence</div><h1 className="text-2xl font-bold tracking-tight text-ink">Investigation history</h1><p className="mt-2 max-w-2xl text-sm text-slate">Review live cases, open verified executive reports, or replay a completed investigation without rerunning the AI.</p></div>
        <div className="flex items-center gap-3"><div className="relative w-72"><Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-300" /><Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search investigations..." className="pl-9" /></div><div className="relative"><Filter className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-300" /><Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as InvestigationStatus | "all")} className="w-48 pl-9"><option value="all">All statuses</option><option value="created">Created</option><option value="planning">Planning</option><option value="investigating">Investigating</option><option value="verifying">Verifying</option><option value="awaiting_capability_approval">Awaiting Approval</option><option value="completed">Completed</option><option value="failed">Failed</option></Select></div></div>
      </div>

      <div className="grid gap-4 sm:grid-cols-3"><Metric label="Verified investigations" value="184" note="96.4% independently verified" /><Metric label="Median resolution" value="11m 42s" note="32% faster this quarter" /><Metric label="Knowledge reused" value="68%" note="Across completed investigations" /></div>

      {curated.length > 0 && <section><div className="mb-3 flex items-center justify-between"><div><h2 className="text-sm font-semibold text-ink">Featured completed investigations</h2><p className="text-xs text-slate">Curated demo history with deterministic replay</p></div><Badge tone="green" dot>Demo ready</Badge></div><div className="grid gap-4 xl:grid-cols-3">{curated.map((item) => <Card key={item.id} hover className="group overflow-hidden"><div className="border-b border-slate-200/40 bg-gradient-to-br from-white to-ice/70 p-5"><div className="flex items-start justify-between gap-4"><Badge tone="green" dot>Verified</Badge><span className="text-2xs text-slate-300">{item.completed}</span></div><h3 className="mt-4 min-h-12 text-sm font-semibold leading-6 text-ink">{item.title}</h3><p className="mt-2 line-clamp-2 text-xs leading-5 text-slate">{item.rootCause}</p></div><div className="grid grid-cols-3 divide-x divide-slate-200/40 border-b border-slate-200/40"><MiniMetric label="Confidence" value={`${item.confidence}%`} /><MiniMetric label="Duration" value={item.duration} /><MiniMetric label="Sources" value={String(item.systems.length)} /></div><div className="flex gap-2 p-4"><button onClick={() => navigate(`/history/${item.id}`)} className="flex flex-1 cursor-pointer items-center justify-center gap-2 rounded-xl bg-midnight px-3 py-2.5 text-xs font-semibold text-white transition hover:bg-midnight-600"><FileText className="h-3.5 w-3.5" /> Open report</button><button onClick={() => navigate(`/replay/${item.id}`)} className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-slate-200/70 px-3 py-2.5 text-xs font-semibold text-ink transition hover:border-enterprise/30 hover:bg-enterprise/5 hover:text-enterprise"><Play className="h-3.5 w-3.5" /> Replay</button></div></Card>)}</div></section>}

      <section><div className="mb-3"><h2 className="text-sm font-semibold text-ink">Workspace investigations</h2><p className="text-xs text-slate">Live records returned by the investigation API</p></div><Card className="overflow-hidden">{filtered.length === 0 ? <div className="flex flex-col items-center justify-center px-6 py-12 text-center"><ShieldCheck className="h-8 w-8 text-enterprise/40" /><p className="mt-3 text-sm font-semibold text-ink">No live workspace investigations yet</p><p className="mt-1 text-xs text-slate">Start an investigation from the dashboard. Featured history remains available for the demo.</p></div> : <table className="w-full text-sm"><thead><tr className="border-b border-slate-200/50 text-2xs uppercase tracking-wider text-slate-300"><th className="px-4 py-3 text-left font-semibold">Status</th><th className="px-4 py-3 text-left font-semibold">Investigation</th><th className="px-4 py-3 text-left font-semibold">Impact</th><th className="px-4 py-3 text-left font-semibold">Confidence</th><th className="px-4 py-3 text-left font-semibold">Duration</th><th className="px-4 py-3 text-left font-semibold">Updated</th></tr></thead><tbody>{filtered.map((inv) => <tr key={inv.investigation_id} onClick={() => navigate(`/investigation/${inv.investigation_id}`)} className="cursor-pointer border-b border-slate-200/30 transition-colors last:border-0 hover:bg-ice-100/50"><td className="px-4 py-3"><StatusBadge status={inv.status} /></td><td className="max-w-xs px-4 py-3"><p className="truncate font-medium text-ink">{inv.incident_title}</p><p className="mt-0.5 truncate text-2xs text-slate-300">{inv.classification?.business_process ?? "Enterprise operations"}</p></td><td className="px-4 py-3 text-slate">{inv.business_impact ? formatCurrency(inv.business_impact.affected_value, inv.business_impact.currency) : "—"}</td><td className="px-4 py-3 capitalize text-slate">{inv.root_cause?.confidence ?? "—"}</td><td className="px-4 py-3 text-slate"><span className="inline-flex items-center gap-1"><Clock3 className="h-3.5 w-3.5 text-slate-300" />{formatDuration(inv.created_at, inv.completed_at)}</span></td><td className="px-4 py-3 text-slate-300">{formatRelativeTime(inv.updated_at)}</td></tr>)}</tbody></table>}</Card></section>
    </div>
  );
}

function Metric({ label, value, note }: { label: string; value: string; note: string }) { return <Card className="p-5"><p className="text-2xs font-semibold uppercase tracking-wider text-slate-300">{label}</p><p className="mt-2 text-2xl font-bold tracking-tight text-ink">{value}</p><p className="mt-1 text-xs text-slate">{note}</p></Card>; }
function MiniMetric({ label, value }: { label: string; value: string }) { return <div className="px-3 py-3 text-center"><p className="text-[9px] font-semibold uppercase tracking-wider text-slate-300">{label}</p><p className="mt-1 text-xs font-bold text-ink">{value}</p></div>; }
