export type HistoricalInvestigation = {
  id: string;
  title: string;
  summary: string;
  rootCause: string;
  impact: string;
  confidence: number;
  duration: string;
  completed: string;
  systems: string[];
  stages: Array<{ title: string; actor: string; summary: string; evidence: string }>;
  recommendations: string[];
};

export const historicalInvestigations: HistoricalInvestigation[] = [
  {
    id: "hist-settlement-v2",
    title: "Cross-border payments pending after morning production deployment",
    summary: "Corporate payments completed validation and booking but remained pending in settlement shortly after a production release.",
    rootCause: "The release introduced settlement-next-v2, but the new queue consumer remained inactive in production, leaving validated payments unconsumed.",
    impact: "1,284 payments · EUR 47.6M delayed",
    confidence: 98,
    duration: "3m 42s",
    completed: "Today, 09:18",
    systems: ["Payment Events", "Settlement Queue", "Deployment Registry"],
    stages: [
      { title: "Incident received", actor: "Operations", summary: "Pending cross-border corporate payments increased after the morning release.", evidence: "1,284 records matched the affected cohort." },
      { title: "Payment investigation", actor: "Payment Investigation", summary: "Validated payments were booked successfully but did not transition to settlement.", evidence: "Booking success 100%; settlement transition absent." },
      { title: "Data contract analysis", actor: "Data Contract Analysis", summary: "Mandatory payment attributes were present and schema contracts remained compatible.", evidence: "No contract drift across 23 required fields." },
      { title: "Pipeline reliability", actor: "Pipeline Reliability", summary: "Scheduled pipelines and upstream producers were healthy, narrowing the fault to downstream consumption.", evidence: "Producer throughput normal; queue depth rising." },
      { title: "Capability activated", actor: "Governance", summary: "Deployment Analysis was approved and activated for this investigation.", evidence: "Approval captured with scoped, read-only access." },
      { title: "Release correlation", actor: "Deployment Analysis", summary: "The release created settlement-next-v2 without activating its production consumer.", evidence: "Consumer group registered but zero active members." },
      { title: "Independent verification", actor: "Independent Verification", summary: "Alternative causes were tested and the release-to-queue causal chain was confirmed.", evidence: "98% verified confidence; no contradictory evidence." },
    ],
    recommendations: ["Activate the settlement-next-v2 consumer group", "Add post-deployment queue-consumer validation", "Backfill the delayed settlement cohort"],
  },
  {
    id: "hist-source-currency",
    title: "FX publication failures for enriched payment events",
    summary: "A subset of international payment events failed downstream FX publication while core processing remained healthy.",
    rootCause: "A producer mapping omitted source_currency for one event variant, causing downstream enrichment rejection.",
    impact: "386 events · USD 8.9M affected",
    confidence: 97,
    duration: "5m 08s",
    completed: "Yesterday, 16:42",
    systems: ["Payment API", "FX Enrichment", "Publication Service"],
    stages: [
      { title: "Incident received", actor: "Operations", summary: "FX publication errors increased for international transfers.", evidence: "Failures isolated to one event variant." },
      { title: "Payment investigation", actor: "Payment Investigation", summary: "The affected cohort shared a missing source currency value.", evidence: "386 of 386 failed records had source_currency null." },
      { title: "Data contract analysis", actor: "Data Contract Analysis", summary: "The field remained mandatory in the approved contract.", evidence: "Contract version unchanged and field required." },
      { title: "Pipeline reliability", actor: "Pipeline Reliability", summary: "Transport and scheduled processing were healthy.", evidence: "No lag, retries, or infrastructure errors." },
      { title: "Independent verification", actor: "Independent Verification", summary: "Successful and failed cohorts confirmed the mapping defect.", evidence: "97% verified confidence." },
    ],
    recommendations: ["Restore source_currency mapping", "Add contract tests for event variants", "Replay failed publication events"],
  },
  {
    id: "hist-duplicate-release",
    title: "Duplicate payment notifications after service restart",
    summary: "Clients received duplicate completion notifications following an unplanned service restart.",
    rootCause: "The notification worker replayed an uncommitted offset while the idempotency cache was unavailable during warm-up.",
    impact: "742 duplicate notifications · no duplicate bookings",
    confidence: 95,
    duration: "6m 31s",
    completed: "Jul 20, 14:07",
    systems: ["Notification Worker", "Kafka", "Idempotency Cache"],
    stages: [
      { title: "Incident received", actor: "Client Support", summary: "Duplicate completion notifications were reported after restart.", evidence: "742 duplicate notification IDs identified." },
      { title: "Payment investigation", actor: "Payment Investigation", summary: "Bookings remained unique; duplication occurred after core processing.", evidence: "No duplicate ledger or booking records." },
      { title: "Pipeline reliability", actor: "Pipeline Reliability", summary: "Consumer offsets replayed during cache warm-up.", evidence: "Offset rewind aligned to worker restart timestamp." },
      { title: "Independent verification", actor: "Independent Verification", summary: "The replay and unavailable idempotency cache jointly explained the duplicates.", evidence: "95% verified confidence." },
    ],
    recommendations: ["Gate worker readiness on cache availability", "Persist idempotency keys across restart", "Alert on unexpected offset rewind"],
  },
];

export const getHistoricalInvestigation = (id?: string) => historicalInvestigations.find((item) => item.id === id);
