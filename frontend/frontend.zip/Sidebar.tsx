import { NavLink, useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import { BarChart3, BookOpen, Bot, ChevronLeft, LayoutDashboard, ListChecks, Plus, Scale, Settings } from "lucide-react";
import { cn } from "@/lib/utils";
import { OrbitMotif } from "@/components/ui/OrbitMotif";

interface SidebarProps { collapsed: boolean; setCollapsed: (v: boolean) => void; approvalCount: number; }
const navItems = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard },
  { to: "/new", label: "Start Investigation", icon: Plus },
  { to: "/investigations", label: "Investigations", icon: ListChecks },
  { to: "/specialists", label: "AI Specialists", icon: Bot },
  { to: "/knowledge", label: "Knowledge Center", icon: BookOpen },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/governance", label: "Governance", icon: Scale },
];

export function Sidebar({ collapsed, setCollapsed, approvalCount }: SidebarProps) {
  const navigate = useNavigate();
  return (
    <motion.aside animate={{ width: collapsed ? 76 : 252 }} transition={{ duration: .2 }} className="relative z-30 flex h-screen shrink-0 flex-col border-r border-white/10 bg-midnight text-white shadow-2xl">
      <div className="flex h-16 items-center border-b border-white/10 px-4">
        <button onClick={() => navigate("/")} className="flex min-w-0 items-center gap-3 text-left">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-electric/30 bg-white/5 text-electric"><OrbitMotif size={23} progress={1} /></div>
          {!collapsed && <div className="min-w-0"><p className="truncate text-sm font-semibold tracking-tight">Resolution AI</p><p className="text-2xs text-slate-200">Enterprise Platform</p></div>}
        </button>
      </div>
      {!collapsed && <div className="mx-3 mt-4 rounded-xl border border-approval/20 bg-approval/8 px-3 py-2"><p className="text-2xs font-semibold uppercase tracking-[.16em] text-approval-300">10 years of innovation</p><p className="mt-1 text-2xs text-slate-200">Enterprise AI, governed by design</p></div>}
      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4 scrollbar-thin">
        {navItems.map(({ to, label, icon: Icon }) => <NavLink key={to} to={to} end={to === "/"} className={({ isActive }) => cn("group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all", isActive ? "bg-white/10 text-white shadow-inner" : "text-slate-200 hover:bg-white/6 hover:text-white")}><Icon className="h-4 w-4 shrink-0" />{!collapsed && <span className="truncate">{label}</span>}{!collapsed && to === "/investigations" && approvalCount > 0 && <span className="ml-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-approval px-1 text-2xs font-bold text-white">{approvalCount}</span>}</NavLink>)}
      </nav>
      <div className="border-t border-white/10 p-3">
        <NavLink to="/settings" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-200 hover:bg-white/6 hover:text-white"><Settings className="h-4 w-4" />{!collapsed && <span>Settings</span>}</NavLink>
        <button onClick={() => setCollapsed(!collapsed)} className="mt-1 flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-slate-200 hover:bg-white/6 hover:text-white"><ChevronLeft className={cn("h-4 w-4 transition-transform", collapsed && "rotate-180")} />{!collapsed && <span>Collapse</span>}</button>
      </div>
    </motion.aside>
  );
}
