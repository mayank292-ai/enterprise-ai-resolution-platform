import type { ReactNode } from "react";
import {
  Activity,
  BarChart3,
  BookOpen,
  CheckCircle2,
  Database,
  GitBranch,
  LockKeyhole,
  Network,
  Search,
  ShieldCheck,
  Sparkles,
  Timer,
  Users,
} from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";

const specialists = [
  { name: "Payment Investigation", domain: "Payments", icon: Activity, success: "96%", cases: 184, status: "Available" },
  { name: "Data Contract Analysis", domain: "Data Quality", icon: Database, success: "94%", cases: 127, status: "Available" },
  { name: "Pipeline Reliability", domain: "Platform", icon: GitBranch, success: "92%", cases: 109, status: "Available" },
  { name: "Deployment Analysis", domain: "Change", icon: Network, success: "91%", cases: 63, status: "Activated" },
  { name: "Independent Verification", domain: "Assurance", icon: ShieldCheck, success: "98%", cases: 171, status: "Available" },
];

export function SpecialistsPage() {
  return (
    <PageFrame eyebrow="Enterprise intelligence" title="AI Specialists" description="Governed domain specialists available to the investigation orchestrator.">
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {specialists.map(({ name, domain, icon: Icon, success, cases, status }) => (
          <Card key={name} hover className="p-5">
            <div className="flex items-start justify-between gap-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-enterprise/8 text-enterprise"><Icon className="h-5 w-5" /></div>
              <Badge tone={status === "Activated" ? "green" : "blue"} dot>{status}</Badge>
            </div>
            <h3 className="mt-5 text-base font-semibold text-ink">{name}</h3>
            <p className="mt-1 text-xs text-slate">{domain} intelligence and evidence analysis</p>
            <div className="mt-5 grid grid-cols-2 gap-3 border-t border-slate-200/40 pt-4">
              <Metric label="Success rate" value={success} />
              <Metric label="Investigations" value={String(cases)} />
            </div>
          </Card>
        ))}
      </div>
    </PageFrame>
  );
}

const patterns = [
  ["Pending settlement after release", "Payments · Change", "12 investigations", "High confidence"],
  ["Missing source currency propagation", "Payments · Data", "8 investigations", "Verified"],
  ["Healthy pipeline with stale downstream queue", "Platform · Messaging", "6 investigations", "High confidence"],
  ["Schema drift after producer deployment", "Data Contract", "10 investigations", "Verified"],
];

export function KnowledgePage() {
  return (
    <PageFrame eyebrow="Institutional learning" title="Knowledge Center" description="Reusable investigation patterns and verified operational knowledge.">
      <Card className="mb-5 p-4">
        <div className="flex items-center gap-3 rounded-xl border border-slate-200/50 bg-ice px-4 py-3 text-sm text-slate">
          <Search className="h-4 w-4 text-slate-300" />
          Search root causes, evidence patterns, systems, or recommendations
        </div>
      </Card>
      <div className="grid gap-4 lg:grid-cols-2">
        {patterns.map(([title, domain, usage, confidence]) => (
          <Card key={title} hover className="p-5">
            <div className="flex items-start justify-between gap-4">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-electric/10 text-enterprise"><BookOpen className="h-4 w-4" /></div>
              <Badge tone={confidence === "Verified" ? "green" : "blue"}>{confidence}</Badge>
            </div>
            <h3 className="mt-4 text-sm font-semibold text-ink">{title}</h3>
            <p className="mt-1 text-xs text-slate">{domain}</p>
            <p className="mt-4 text-2xs text-slate-300">Reused across {usage}</p>
          </Card>
        ))}
      </div>
    </PageFrame>
  );
}

export function AnalyticsPage() {
  const bars = [42, 58, 51, 68, 74, 63, 82, 77, 88, 91, 86, 96];
  return (
    <PageFrame eyebrow="Operational performance" title="Analytics" description="Investigation effectiveness, resolution velocity, and specialist utilization.">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi icon={CheckCircle2} label="Completed" value="184" note="+18% this month" />
        <Kpi icon={Timer} label="Median resolution" value="11m 42s" note="32% faster" />
        <Kpi icon={ShieldCheck} label="Verified outcomes" value="96.4%" note="Last 90 days" />
        <Kpi icon={Users} label="Human approvals" value="14" note="7.6% of cases" />
      </div>
      <div className="mt-5 grid gap-5 xl:grid-cols-[1.35fr_.65fr]">
        <Card className="p-5">
          <div className="flex items-center justify-between"><div><h3 className="text-sm font-semibold text-ink">Resolution volume</h3><p className="text-xs text-slate">Investigations completed over 12 weeks</p></div><Badge tone="green">Healthy</Badge></div>
          <div className="mt-8 flex h-56 items-end gap-2">
            {bars.map((height, index) => <div key={index} className="flex-1 rounded-t-md bg-enterprise/80 transition-all hover:bg-electric" style={{ height: `${height}%` }} />)}
          </div>
        </Card>
        <Card className="p-5">
          <h3 className="text-sm font-semibold text-ink">Top root-cause domains</h3>
          <div className="mt-5 space-y-5">
            {[['Data contracts','34%'],['Release changes','27%'],['Pipeline reliability','23%'],['Payment processing','16%']].map(([label,value]) => (
              <div key={label}><div className="mb-2 flex justify-between text-xs"><span className="text-slate">{label}</span><span className="font-semibold text-ink">{value}</span></div><div className="h-2 rounded-full bg-ice-200"><div className="h-2 rounded-full bg-enterprise" style={{ width: value }} /></div></div>
            ))}
          </div>
        </Card>
      </div>
    </PageFrame>
  );
}

export function GovernancePage() {
  return (
    <PageFrame eyebrow="Trust and control" title="Governance" description="Human decisions, capability activation, and end-to-end auditability.">
      <div className="grid gap-4 sm:grid-cols-3">
        <Kpi icon={LockKeyhole} label="Policy compliance" value="100%" note="No exceptions" />
        <Kpi icon={ShieldCheck} label="Approved capabilities" value="4" note="All auditable" />
        <Kpi icon={Activity} label="Open approvals" value="1" note="Requires review" />
      </div>
      <Card className="mt-5 overflow-hidden">
        <div className="border-b border-slate-200/40 px-5 py-4"><h3 className="text-sm font-semibold text-ink">Recent governance activity</h3></div>
        <div className="divide-y divide-slate-200/40">
          {[
            ["Deployment Analysis capability approved", "M. Sharma", "Cross-border settlement investigation", "Approved"],
            ["Independent verification completed", "Verification Specialist", "Payment publication incident", "Verified"],
            ["Capability policy evaluated", "Resolution Supervisor", "Morning production release", "Compliant"],
          ].map(([title, actor, context, status]) => (
            <div key={title} className="grid gap-3 px-5 py-4 md:grid-cols-[1.5fr_.75fr_1fr_auto] md:items-center">
              <div><p className="text-sm font-medium text-ink">{title}</p><p className="text-2xs text-slate-300">{context}</p></div>
              <span className="text-xs text-slate">{actor}</span><span className="text-xs text-slate">Today</span><Badge tone="green" dot>{status}</Badge>
            </div>
          ))}
        </div>
      </Card>
    </PageFrame>
  );
}

export function SettingsPage() {
  return (
    <PageFrame eyebrow="Workspace administration" title="Settings" description="Workspace identity and experience preferences.">
      <div className="grid gap-5 xl:grid-cols-2">
        <Card className="p-5"><h3 className="text-sm font-semibold text-ink">Workspace</h3><div className="mt-5 space-y-4"><SettingRow label="Workspace name" value="Payments Operations" /><SettingRow label="Team" value="Enterprise Resolution" /><SettingRow label="Environment" value="Production" /></div></Card>
        <Card className="p-5"><h3 className="text-sm font-semibold text-ink">Experience</h3><div className="mt-5 space-y-4"><SettingRow label="Investigation refresh" value="Automatic" /><SettingRow label="Evidence detail" value="Business summary" /><SettingRow label="Technical trace" value="Available on demand" /></div></Card>
      </div>
    </PageFrame>
  );
}

function PageFrame({ eyebrow, title, description, children }: { eyebrow: string; title: string; description: string; children: ReactNode }) {
  return <div className="mx-auto max-w-7xl px-6 py-8 lg:px-8"><div className="mb-7"><div className="mb-2 flex items-center gap-2 text-2xs font-semibold uppercase tracking-[0.18em] text-enterprise"><Sparkles className="h-3.5 w-3.5" />{eyebrow}</div><h1 className="text-2xl font-bold tracking-tight text-ink">{title}</h1><p className="mt-2 max-w-2xl text-sm text-slate">{description}</p></div>{children}</div>;
}

function Metric({ label, value }: { label: string; value: string }) { return <div><p className="text-2xs uppercase tracking-wider text-slate-300">{label}</p><p className="mt-1 text-sm font-semibold text-ink">{value}</p></div>; }
function Kpi({ icon: Icon, label, value, note }: { icon: typeof BarChart3; label: string; value: string; note: string }) { return <Card className="p-5"><div className="flex items-center justify-between"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-enterprise/8 text-enterprise"><Icon className="h-4 w-4" /></div><Badge tone="neutral">Live</Badge></div><p className="mt-4 text-2xs font-semibold uppercase tracking-wider text-slate-300">{label}</p><p className="mt-1 text-2xl font-bold tracking-tight text-ink">{value}</p><p className="mt-1 text-xs text-slate">{note}</p></Card>; }
function SettingRow({ label, value }: { label: string; value: string }) { return <div className="flex items-center justify-between rounded-xl border border-slate-200/50 bg-ice/70 px-4 py-3"><span className="text-xs text-slate">{label}</span><span className="text-xs font-semibold text-ink">{value}</span></div>; }
