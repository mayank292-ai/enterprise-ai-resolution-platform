import { useNavigate } from "react-router-dom";
import { Bell, ChevronDown, ChevronRight, Search } from "lucide-react";
import { useCommandPalette } from "@/components/CommandPalette";
import { cn } from "@/lib/utils";
interface TopBarProps { title: string; breadcrumb?: string[]; approvalCount?: number; onApprovalClick?: () => void; }
export function TopBar({ breadcrumb, approvalCount = 0, onApprovalClick }: TopBarProps) {
  const navigate = useNavigate(); const palette = useCommandPalette();
  return <header className="sticky top-0 z-20 flex h-16 items-center gap-4 border-b border-slate-200/50 bg-white/90 px-5 backdrop-blur-xl lg:px-7">
    <div className="flex min-w-0 items-center gap-1.5 text-sm">{breadcrumb?.map((crumb, i) => <span key={crumb + i} className="flex min-w-0 items-center gap-1.5">{i > 0 && <ChevronRight className="h-3.5 w-3.5 shrink-0 text-slate-300" />}<span className={cn("truncate", i === breadcrumb.length - 1 ? "font-semibold text-ink" : "cursor-pointer text-slate hover:text-ink")} onClick={() => i === 0 && navigate("/")}>{crumb}</span></span>)}</div>
    <div className="flex-1" />
    <button className="hidden items-center gap-2 rounded-xl border border-slate-200/60 bg-ice/70 px-3 py-2 text-xs text-slate transition hover:border-electric/40 sm:flex" onClick={() => palette?.setOpen(true)}><Search className="h-3.5 w-3.5" /><span className="min-w-28 text-left">Search platform</span><kbd className="rounded-md border border-slate-200/60 bg-white px-1.5 py-0.5 font-mono text-2xs text-slate-300">⌘K</kbd></button>
    <button className="hidden items-center gap-2 rounded-xl border border-slate-200/60 bg-white px-3 py-2 text-xs font-medium text-ink md:flex"><span className="h-2 w-2 rounded-full bg-verified" />Payments Operations<ChevronDown className="h-3.5 w-3.5 text-slate-300" /></button>
    <button onClick={onApprovalClick} className="relative flex h-9 w-9 items-center justify-center rounded-xl border border-transparent hover:border-slate-200/60 hover:bg-ice" aria-label="Notifications"><Bell className="h-4 w-4 text-slate" />{approvalCount > 0 && <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-approval px-1 text-[9px] font-bold text-white">{approvalCount}</span>}</button>
    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-midnight text-xs font-semibold text-white">MS</div>
  </header>;
}
