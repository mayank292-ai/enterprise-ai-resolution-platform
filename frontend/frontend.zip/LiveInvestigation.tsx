import { useParams } from "react-router-dom";
import { useState } from "react";
import { motion } from "motion/react";
import { Terminal, Clock } from "lucide-react";
import { useInvestigationSession } from "@/hooks/useInvestigations";
import { buildAgentNodes, activeAgentNode } from "@/lib/investigationView";
import { AgentNode } from "@/components/AgentNode";
import { ApprovalPanel } from "@/components/ApprovalPanel";
import { ProvisioningSequence } from "@/components/ProvisioningSequence";
import { RootCauseReveal, VerificationStage } from "@/components/RootCauseReveal";
import { CompletedSummary } from "@/components/CompletedSummary";
import { TraceDrawer } from "@/components/TraceDrawer";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { LoadingState, ErrorState } from "@/components/ui/States";
import { StatusBadge } from "@/components/ui/Badge";
import { formatDuration, titleCase } from "@/lib/utils";

type LocalPhase = "live" | "provisioning";

export function LiveInvestigation() {
  const { id } = useParams<{ id: string }>();
  const { query, approve, resume } = useInvestigationSession(id);
  const [traceOpen, setTraceOpen] = useState(false);
  const [phase, setPhase] = useState<LocalPhase>("live");

  if (query.isLoading) {
    return <LoadingState label="Loading investigation" className="py-24" />;
  }

  if (query.isError || !query.data) {
    return (
      <div className="max-w-2xl mx-auto py-16">
        <ErrorState
          type="recoverable"
          message={(query.error as Error)?.message ?? "Could not load this investigation."}
          onRetry={() => query.refetch()}
        />
      </div>
    );
  }

  const investigation = query.data;

  if (investigation.status === "completed" || investigation.status === "failed") {
    return <CompletedSummary investigation={investigation} />;
  }

  const nodes = buildAgentNodes(investigation);
  const active = activeAgentNode(nodes);
  const gap = investigation.pending_capability_gap;
  const awaitingApproval = investigation.status === "awaiting_capability_approval" && gap;

  const handleApprove = async () => {
    await approve.mutateAsync();
    setPhase("provisioning");
  };

  const handleProvisioned = async () => {
    await resume.mutateAsync();
    setPhase("live");
  };

  return (
    <div className="relative">
      <div className={awaitingApproval || phase === "provisioning" ? "pointer-events-none select-none" : ""}>
        <motion.div
          animate={{ filter: awaitingApproval || phase === "provisioning" ? "blur(3px)" : "blur(0px)" }}
          transition={{ duration: 0.24 }}
        >
          {/* Header */}
          <div className="px-6 pt-6 pb-4 border-b border-slate-200/40 bg-white sticky top-0 z-10">
            <div className="flex items-center justify-between gap-4">
              <div className="min-w-0">
                <div className="flex items-center gap-2 mb-1.5">
                  <StatusBadge status={investigation.status} pulse />
                  {investigation.classification && (
                    <Badge tone="slate">{investigation.classification.priority}</Badge>
                  )}
                </div>
                <h1 className="text-lg font-bold text-ink truncate">{investigation.incident_title}</h1>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <div className="flex items-center gap-1.5 text-xs text-slate">
                  <Clock className="w-3.5 h-3.5" />
                  {formatDuration(investigation.created_at, investigation.completed_at)}
                </div>
                <button
                  onClick={() => setTraceOpen(true)}
                  className="flex items-center gap-1.5 text-xs font-medium text-slate hover:text-ink px-3 py-1.5 rounded-lg border border-slate-200/60 transition-colors"
                >
                  <Terminal className="w-3.5 h-3.5" />
                  Trace
                </button>
              </div>
            </div>
          </div>

          {/* Three zone layout */}
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_1.15fr_0.85fr] gap-5 p-6">
            {/* Left: agent map / timeline */}
            <div className="space-y-3">
              <div className="text-2xs font-semibold text-slate-300 uppercase tracking-wider px-1">
                Agent timeline
              </div>
              {nodes.length === 0 && (
                <Card className="px-4 py-8 text-center text-sm text-slate-300">
                  Waiting for the supervisor to assign the first specialist…
                </Card>
              )}
              {nodes.map((node, i) => (
                <AgentNode key={node.decision.decision_id} node={node} index={i} />
              ))}
            </div>

            {/* Center: active agent + findings */}
            <div className="space-y-4">
              <div className="text-2xs font-semibold text-slate-300 uppercase tracking-wider px-1">
                Findings
              </div>
              {investigation.classification && (
                <Card className="px-4 py-3.5">
                  <p className="text-sm text-ink">{investigation.classification.summary}</p>
                  <p className="text-xs text-slate-300 mt-1">
                    {investigation.classification.category} · {investigation.classification.business_process}
                  </p>
                </Card>
              )}
              {active && (
                <Card className="px-4 py-3.5 border-electric/30 shadow-glow">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-2 h-2 rounded-full bg-electric animate-pulse" />
                    <span className="text-xs font-semibold text-ink">
                      {titleCase(active.decision.agent_name)} is investigating
                    </span>
                  </div>
                  <p className="text-xs text-slate">{active.decision.objective}</p>
                </Card>
              )}
              {investigation.findings.map((f, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.14, delay: i * 0.05 }}
                >
                  <Card className="px-4 py-3.5">
                    <p className="text-sm font-medium text-ink">{f.title}</p>
                    <p className="text-xs text-slate">{f.explanation}</p>
                  </Card>
                </motion.div>
              ))}
              <VerificationStage investigation={investigation} />
              {investigation.root_cause && <RootCauseReveal investigation={investigation} />}
              {investigation.findings.length === 0 && !active && nodes.length === 0 && (
                <Card className="px-4 py-8 text-center text-sm text-slate-300">
                  No findings yet.
                </Card>
              )}
            </div>

            {/* Right: evidence and hypothesis rail */}
            <div className="space-y-4">
              <div className="text-2xs font-semibold text-slate-300 uppercase tracking-wider px-1">
                Hypotheses
              </div>
              {investigation.hypotheses.length === 0 && (
                <Card className="px-4 py-6 text-center text-xs text-slate-300">No hypotheses yet.</Card>
              )}
              {investigation.hypotheses.map((h) => (
                <Card key={h.hypothesis_id} className="px-4 py-3">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <Badge tone={h.status === "confirmed" ? "green" : h.status === "contradicted" ? "red" : "slate"}>
                      {h.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-ink">{h.statement}</p>
                </Card>
              ))}

              <div className="text-2xs font-semibold text-slate-300 uppercase tracking-wider px-1 pt-2">
                Evidence
              </div>
              {investigation.evidence.length === 0 && (
                <Card className="px-4 py-6 text-center text-xs text-slate-300">No evidence yet.</Card>
              )}
              {investigation.evidence.map((e) => (
                <Card key={e.evidence_id} className="px-4 py-3">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-xs font-medium text-ink truncate">{e.title}</span>
                    <Badge tone={e.confidence === "verified" ? "green" : "neutral"}>{e.confidence}</Badge>
                  </div>
                  <p className="text-2xs text-slate">{e.summary}</p>
                </Card>
              ))}
            </div>
          </div>
        </motion.div>
      </div>

      {awaitingApproval && phase === "live" && (
        <ApprovalPanel
          gap={gap}
          onApprove={handleApprove}
          approving={approve.isPending}
          approveError={approve.error ? (approve.error as Error).message : null}
        />
      )}

      {phase === "provisioning" && gap && (
        <ProvisioningSequence agentName={gap.proposed_agent_name} onComplete={handleProvisioned} />
      )}

      <TraceDrawer investigation={investigation} open={traceOpen} onClose={() => setTraceOpen(false)} />
    </div>
  );
}
