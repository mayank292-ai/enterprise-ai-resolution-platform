import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Navigate, Route, Routes, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { TopBar } from "@/components/TopBar";
import { CommandPaletteProvider } from "@/components/CommandPalette";
import { CommandCenter } from "@/pages/CommandCenter";
import { StartInvestigation } from "@/pages/StartInvestigation";
import { LiveInvestigation } from "@/pages/LiveInvestigation";
import { Archive } from "@/pages/Archive";
import { DevMenu } from "@/pages/DevMenu";
import { AnalyticsPage, GovernancePage, KnowledgePage, SettingsPage, SpecialistsPage } from "@/pages/VisionPages";
import { InvestigationReplay } from "@/pages/InvestigationReplay";
import { HistoricalReport } from "@/pages/HistoricalReport";
import { useInvestigationsList } from "@/hooks/useInvestigations";
const queryClient = new QueryClient({ defaultOptions: { queries: { refetchOnWindowFocus: false, retry: 1 } } });
const breadcrumbMap: Record<string, string[]> = { "/": ["Dashboard"], "/new": ["Dashboard", "Start Investigation"], "/investigations": ["Investigations"], "/specialists": ["AI Specialists"], "/knowledge": ["Knowledge Center"], "/analytics": ["Analytics"], "/governance": ["Governance"], "/settings": ["Settings"], "/dev": ["Developer Menu"] };
function AnimatedRoutes({ approvalCount }: { approvalCount: number }) { const location = useLocation(); const crumbs = breadcrumbMap[location.pathname] ?? (location.pathname.startsWith("/investigation/") ? ["Investigations", "Investigation"] : ["Dashboard"]); return <><TopBar title={crumbs.at(-1) ?? "Dashboard"} breadcrumb={crumbs} approvalCount={approvalCount} /><main className="flex-1 overflow-y-auto scrollbar-thin"><AnimatePresence mode="wait"><motion.div key={location.pathname} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }} transition={{ duration: .18 }} className="min-h-full"><Routes location={location}><Route path="/" element={<CommandCenter />} /><Route path="/new" element={<StartInvestigation />} /><Route path="/investigations" element={<Archive />} /><Route path="/archive" element={<Navigate to="/investigations" replace />} /><Route path="/investigation/:id" element={<LiveInvestigation />} /><Route path="/history/:id" element={<HistoricalReport />} /><Route path="/replay/:id" element={<InvestigationReplay />} /><Route path="/specialists" element={<SpecialistsPage />} /><Route path="/capabilities" element={<Navigate to="/specialists" replace />} /><Route path="/knowledge" element={<KnowledgePage />} /><Route path="/analytics" element={<AnalyticsPage />} /><Route path="/governance" element={<GovernancePage />} /><Route path="/settings" element={<SettingsPage />} /><Route path="/dev" element={<DevMenu />} /><Route path="*" element={<Navigate to="/" replace />} /></Routes></motion.div></AnimatePresence></main></>; }
function AppShell() { const [collapsed, setCollapsed] = useState(false); const { data } = useInvestigationsList(); const approvalCount = (data ?? []).filter(i => i.status === "awaiting_capability_approval").length; return <div className="flex h-screen overflow-hidden bg-ice"><Sidebar collapsed={collapsed} setCollapsed={setCollapsed} approvalCount={approvalCount} /><div className="flex min-w-0 flex-1 flex-col"><AnimatedRoutes approvalCount={approvalCount} /></div></div>; }
export default function App() { return <QueryClientProvider client={queryClient}><BrowserRouter><CommandPaletteProvider><AppShell /></CommandPaletteProvider></BrowserRouter></QueryClientProvider>; }
